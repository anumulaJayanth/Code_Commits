const movie = require('../Models/movies')
const bodyparser = require('body-parser')
exports.getmovies=(req,res)=>{
    movie.find().then(
        result=>{
            res.status(200).json({
                titles: result,
                message: "successfully fetched list of movies"
            });
        }).catch(err => {
            res.status(500).json({
                error : err,
                message : "Error in fetching movies"
            });
        });

}


exports.createmovies = (req, res) => {
    // logic to create the students in the mongodb
    const  {
        title,
        links
    } = req.body;

    const movieObject = new movie({
        title: title,
        links: links
    });

    movieObject.save().then(result => {
        res.status(200).json({
            movies: result,
            message: "Successfully created the movie"
        });
    }).catch(err => {
        res.status(500).json({
            error: err
        });
    });
}



exports.updatemovie = (req, res) => {
    // logic to update the student in the mongodb
    const {
        title,
        links
    } = req.body;

    const movieId = req.params.movieId;

    movie.findOneAndUpdate(
        { _id: movieId },
        {
            $set: {
                title: title,
                links: links
            }
        },
        { upsert: true }
    ).then(result => {
        res.status(200).json({
            movies: result,
            message: "Successfully updated the movie"
        });
    }).catch(err => {
        res.status(500).json({
            error: err
        });
    });

}