const express = require('express')
const mongoose = require('mongoose')
const mongodb = require('mongodb').MongoClient
const router = require('./Routers/index')
const bodyparser = require('body-parser')
const app = express()
app.use(bodyparser.json())
const connectionString = 'mongodb+srv://Jayanth:abcdefg@cluster0.hxncz.mongodb.net/mongo?retryWrites=true&w=majority'
const connectionStringlocal= 'mongodb://127.0.0.1:27017/'

const port = 4500
app.use('/', router)

mongoose.connect(
    connectionString,
    {
        useNewUrlParser: true,
        useUnifiedTopology: true
    }
).then(response => {
    console.log("connected to mongodb")

    app.listen(port, ()=>{
        console.log("Server is running")
    })
}).catch(err => {
    console.log(err)
})