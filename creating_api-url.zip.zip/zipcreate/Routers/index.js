const moviesController = require('../Controllers/movies')
const express = require('express')
const router = express.Router()
router.get('/getmovies',moviesController.getmovies)
router.post('/createmovies',moviesController.createmovies)
router.put('/updatemovie/:movieId',moviesController.updatemovie)
module.exports = router;