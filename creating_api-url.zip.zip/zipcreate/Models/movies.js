const mongoose = require('mongoose')
const Schema = mongoose.Schema
const testschema = new Schema ({
    "title" : {
        type : String
    },
    "links" : {
        type : String
    },
})

module.exports = mongoose.model('movies',testschema,'test')