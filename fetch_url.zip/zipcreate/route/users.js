const express = require("express");
const router = express.Router();

const fetch = require("node-fetch");


router.get("/",(req,res)=>{

    fetch("https://jsonplaceholder.typicode.com/users").then((data)=>{
        console.log("entered the fetch");
        return data.json();
    }).then((result)=>{
        res.status(200).send(result);
    });

});

module.exports = router;

// The Api which was provided was not working so I had used another api to fetch data in it.