const express = require("express");
const fs = require("fs");
const app = express();
const port = 2500;

app.listen(port,()=>{
    console.log("app is running on port %s",port);
});

app.get('/',(req,res)=>{
    fs.readFile('links.json',(err,data)=>{
        if(err){
            throw err;
        }else{
            res.send(JSON.parse(data));
        }
    })
})