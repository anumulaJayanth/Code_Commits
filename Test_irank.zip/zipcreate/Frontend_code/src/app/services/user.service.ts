import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {User} from '../model/user.model'

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(
    private httpClient: HttpClient
  ) { }

  registerUser(data:User){
    return this.httpClient.post('http://localhost:3000/createUser', data)
  }

  getUserById(id: any){
    return this.httpClient.get('http://localhost:3000/getUsers/'+id)
  }
  updateUser(email:any,data: any){
    return this.httpClient.put('http://localhost:3000/updateUser/'+email, data)
  }

  
}
