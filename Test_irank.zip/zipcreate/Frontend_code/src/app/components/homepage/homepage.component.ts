import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service'
import { User } from 'src/app/model/user.model';
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  public userForm : any
  public userFormSubmitted : boolean;

  constructor(
    private userService: UserService
  ) { 
    this.userForm ={}
    this.userFormSubmitted = false
  }

  public ngOnInit(): void {
  }

  public OnSubmit(): void {

    this.userFormSubmitted = true
    this.userService.updateUser(this.userForm.email,this.userForm).subscribe(data => {console.log('Success!',data),
      (error:any) => (console.log(error))
  })
  }  

}
