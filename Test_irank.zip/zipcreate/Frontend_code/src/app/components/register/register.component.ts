import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/model/user.model';
import { UserService } from '../../services/user.service'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  public userForm : any;
  public userFormSubmitted : boolean;
  constructor(
    private userService: UserService
  ) { 
    this.userForm = {}
    this.userFormSubmitted = false;
  }

  public ngOnInit(): void {
  }

  public OnSubmit(): void {

    this.userFormSubmitted = true
    console.log(this.userForm)
    this.userService.registerUser(this.userForm).subscribe(data => {console.log('Success!',data),
      (error:any) => (console.log(error))
  })
  }

}
