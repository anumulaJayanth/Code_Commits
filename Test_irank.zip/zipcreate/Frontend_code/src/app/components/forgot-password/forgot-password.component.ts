import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service'

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  public userForm : any
  public userFormSubmitted : boolean;
  public userDetails : any
  public password : any
  constructor(
    private userService: UserService
  ) {
   
    this.userForm ={}
    this.userFormSubmitted = false
    this.userDetails ={}
   }

  public ngOnInit(): void {
  }

  public OnSubmit(): void {
    this.userService.getUserById(this.userForm.email).subscribe(data => {
      this.userDetails = data,
      (error:any) => (console.log(error))
    if(this.userForm.phonenumber == this.userDetails.user[0].phonenumber) {
      this.userFormSubmitted = true
    }else{
      alert("Please enter correct credentials")
    }
  })



  }

}
