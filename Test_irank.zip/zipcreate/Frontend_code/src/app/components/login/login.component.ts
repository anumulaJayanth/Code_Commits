import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service'
import {Router} from '@angular/router';
import {HomepageComponent} from '../homepage/homepage.component'


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public userForm:any;
  public userFormSubmitted:boolean;
  public userDetails : any

  constructor(
    private userService: UserService,
    private router:Router
  ) { 
    this.userForm ={}
    this.userFormSubmitted = false
    this.userDetails ={}
  }

  public ngOnInit(): void {
  }
 
  public OnSubmit(): void {
    this.userFormSubmitted = true
    this.userService.getUserById(this.userForm.email).subscribe((data) =>{
      this.userDetails= data
      if(this.userForm.email==this.userDetails.user[0].email  && this.userForm.password==this.userDetails.user[0].password){
        this.router.navigate(['/hompage'])
      }else{
        alert("Please enter correct credentials")
      }
    }, (err)=>{
      console.log(err)
    })


  }

}
