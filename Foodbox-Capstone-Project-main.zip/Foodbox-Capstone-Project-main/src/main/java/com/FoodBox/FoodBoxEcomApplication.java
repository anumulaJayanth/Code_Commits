package com.FoodBox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodBoxEcomApplication  {

	public static void main(String[] args) {
		SpringApplication.run(FoodBoxEcomApplication.class, args);
	}

}
