package com.FoodBox.Global;

import java.util.ArrayList;
import java.util.List;

import com.FoodBox.Model.Product;

public class GlobalData {
	
	public static List<Product>cart1;
	
	static {
		cart1=new ArrayList<Product>();
	}

}
